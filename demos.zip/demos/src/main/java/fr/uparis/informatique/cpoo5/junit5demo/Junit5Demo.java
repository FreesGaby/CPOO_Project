package fr.uparis.informatique.cpoo5.junit5demo;

public class Junit5Demo {
    public static int fonctionATester() {
        return 42;
    }
}
